Average
=======

Templated class for calculating averages and statistics of data sets.
